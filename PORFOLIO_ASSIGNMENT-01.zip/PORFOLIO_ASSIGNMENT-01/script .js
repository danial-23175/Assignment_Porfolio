document.addEventListener("DOMContentLoaded", function () {
    console.log("Portfolio Loaded Successfully!");
});
